<!DOCTYPE html>
<html>
<head><title>Download zip file</title></head>
<body>
  <form method="POST" action="zipdownload.php">
    <input type="submit" value="Download All Documents"/>
  </form>
</body>
</html>